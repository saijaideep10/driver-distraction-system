from __future__ import unicode_literals
import pyttsx3
import speech_recognition as speech
import datetime
import webbrowser
import os
import json
import wikipedia
from googlesearch import search
from bs4 import BeautifulSoup
import youtube_dl
import sys
import wolframalpha
import datetime
from urllib.request import urlopen
from flask import Flask, url_for, request, render_template

class _TTS:
    engine = None
    rate = None
    def __init__(self):
        self.engine = pyttsx3.init()

    def start(self,text_):
        self.engine.say(text_)
        self.engine.runAndWait()


engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')

# using the male voice to change to female voice change the value accordingly..
engine.setProperty('voices', voices[1].id)

import logging
app = Flask(__name__)
app.logger.setLevel(logging.INFO)

def speak(audio):
    #engine.say(audio)
    #engine.runAndWait()
    tts = _TTS()
    tts.start(audio)
    del(tts)

def start():
    hour = int(datetime.datetime.now().hour)
    if hour>=0 and hour<=12 :
        speak('Good morning ...')
    elif hour >=12 and hour <=18 :
        speak('Good afternoon ...')
    else :
        speak('Good evening ...')
# takes command from the user ...
def command() :
    a = speech.Recognizer()
    with speech.Microphone() as source :
        print('Listening......')
        a.pause_threshold = 2
        audio = a.listen(source)
        print(audio)
    try :
        print('Understannding ...')
        query = a.recognize_google(audio, language="en-in")
        print(f"user said : {query}\n")
        speak(query)
    except Exception as e:
        print("say that again please...")
        speak("say that again please...")
        return command()        
    return query
# downloading  songs from youtube (mp3/mp4)
def download () :
    video_url = j
    info = youtube_dl.YoutubeDL().extract_info(url = video_url, download = False)
    #print(info)
    #yt = YouTube(video_url)
    #file_name = yt.title
    file_name = f"{info['title']}.mp3"
    #file_name = video_url
    #print(file_name)
    specs = {
        'format' : 'bestaudio/best' ,
        'keepvideo' : False ,
        'outtmpl' : file_name ,
        'postprocessors' : [{
            'key' : 'FFmpegExtractAudio' ,
            'preferredcodec' : 'mp3' ,
            'preferredquality' : '192' ,
        }]
    }
    with youtube_dl.YoutubeDL(specs) as ydl :
        ydl.download([info['webpage_url']])

    #subprocess.call(["open", file_name])
 
@app.route("/")
def index():
	print("In index method")
	return render_template('index.html')

@app.route('/tsast/')
def tsast():
	print("In TSAST method")
	return render_template('TSAST.html')

#background process happening without any refreshing
@app.route('/background_process_test')
def background_process_test():
    print ("Hello")
    start()
    speak("How may i help you ...")
    
    while True :
        query = command().lower()
        if 'wikipedia' in query :
            print(query)
            #speak('Searching wikipedia .....')
            query = query.replace("wikipedia", " ")
            results = wikipedia.summary(query , sentences = 2)
            print(results)
            speak(results) 
        elif 'open youtube' in query :
            print(query)
            webbrowser.open('www.youtube.com')
         
        elif 'open' in query:
            query = query.replace('open',"")
            for j in search(query, tld="com", num=1, stop=1, pause=2): 
                print(j)
                webbrowser.open_new(j)
                
        elif 'the time' in query:
            strTime = datetime.datetime.now().strftime("%a, %d %b %Y %H:%M:%S")    
            speak(f"Sir, the time is {strTime}")
            
         
        elif 'how are you' in query:
            speak("I am fine, Thank you")
            speak("How are you, Sir")
            
        elif 'fine' in query or "good" in query:
            speak("It's good to know that your fine")
            
        elif 'play' in query:
            query = query.replace('play',"")
            url = ('https://www.youtube.com/results?search_query='+query)
            print(url)
            #for j in search(query, tld="com", num=2, stop=1, pause=2): 
                #print(j)
            webbrowser.open_new(url)
            #youtube_dl.YoutubeDL.urlopen(j)
                               
                        
        elif "calculate" in query: 
             
            app_id = '5L9WRH-XVPAQRLH88'
            client = wolframalpha.Client(app_id)
            indx = query.lower().split().index('calculate') 
            query = query.split()[indx + 1:] 
            res = client.query(' '.join(query)) 
            answer = next(res.results).text
            print("The answer is " + answer) 
            speak("The answer is " + answer) 
            
            
        elif 'news' in query:
             
            try: 
                jsonObj = urlopen('''http://newsapi.org/v2/top-headlines?country=in&apiKey=8512e2b7e0b74ab9bfb1bfd54338aca0''')
                data = json.load(jsonObj)
                i = 1
                 
                speak('here are some top news from the times of india')
                print('''=============== TIMES OF INDIA ============'''+ '\n')
                 
                for item in data['articles']:
                     
                    print(str(i) + '. ' + item['title'] + '\n')
                    print(item['description'] + '\n')
                    speak(str(i) + '. ' + item['title'] + '\n')
                    i += 1
            except Exception as e:
                 
                print(str(e))
                
        
        elif "where is" in query:
            query = query.replace("where is", "")
            location = query
            speak("User asked to Locate")
            speak(location)
            webbrowser.open("https://www.google.com/maps/place/"+ location)
        
        elif "write a note" in query:
            speak("What should i write, sir")
            note = command()
            file = open('jarvis.txt', 'w')
            speak("Sir, Should i include date and time")
            snfm = command()
            if 'yes' in snfm or 'sure' in snfm:
                strTime = datetime.datetime.now().strftime("%a, %d %b %Y %H:%M:%S")
                file.write(strTime)
                file.write(" :- ")
                file.write(note)
            else:
                file.write(note)
         
        elif "show note" in query:
            speak("Showing Notes")
            file = open("jarvis.txt", "r") 
            print(file.read())
            speak(file.read(6))
            
        elif "what is" in query or "who is" in query:
             
            
            client = wolframalpha.Client("5L9WRH-XVPAQRLH88")
            res = client.query(query)
             
            try:
                print (next(res.results).text)
                speak (next(res.results).text)
            except StopIteration:
                print ("No results")
        
       
        elif 'exit' in query :
            print("In quit function")
            break
    return ("nothing")
 
if __name__ == "__main__":
    app.run(port=5001)